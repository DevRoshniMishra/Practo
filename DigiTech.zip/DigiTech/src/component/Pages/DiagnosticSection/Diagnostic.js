import React, { Component } from 'react'

export default class Diagnostic extends Component {
    render() {
        return (
            <div>
                <h4>Diagnostic Section</h4>
            </div>
        )
    }
}
