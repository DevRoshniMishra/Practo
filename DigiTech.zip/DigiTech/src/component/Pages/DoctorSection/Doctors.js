import React, { Component } from 'react';
import Badge from '../../../assets/download.png';
import '../DoctorSection/Doctors.css';
import Data from '../../../../src/Data/db.json';
import DummyImage from '../../../assets/DummyImage.jpg';
import {Link} from 'react-router-dom';


export default class Doctors extends Component {
    render() {
        return (
            <>
                <div className="container doctor_search">
                    <div className="row">
                        <div className="col-md-8 ">
                            <form className="doctor_search">
                                <input className="search_location" type="search" placeholder="Search Location" />
                                <input className="search_location" type="search" placeholder="Find Doctors" />
                            </form>
                        </div>
                        <div className="col-md-4">
                            <p className="dummy-text">Fed up of endless wait ?</p>
                            <div className="parent-divtext">
                                <p className="dummy-para">Look for clinic with Prime</p>
                                <span><img className="badge-icon" src={Badge} /></span>
                            </div>
                        </div>
                    </div>
                </div>
             
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <div className="row">
                                <div className="col-md-8">
                                    {Data.doctors.map((items, index) => {
                                        return (
                                            <div key={index} className="parent-doc">
                                                <div className="dummy-image">
                                                    <img src={DummyImage} />
                                                    <Link to="/">View Profile</Link>
                                                </div> 
                                                <div>
                                                    <ul className="details-list">
                                                        <li className="name"><Link to="/">{items.name}</Link></li>
                                                        <li className="occupation">{items.occupation}</li>
                                                        <li className="occupation">{items.specialist}</li>
                                                        <li className="occupation">{items.yearsofexp}</li>
                                                        <div className="aline-lists">
                                                            <li>{items.locality}</li>
                                                            <li>{items.workingplace}</li>
                                                        </div>
                                                        <li>{items.charges} Consultation fees at clinic</li>
                                                        <div className="aline-lists">
                                                            <li>{items.email}</li>
                                                            <li>{items.mobilenumber}</li>
                                                        </div>
                                                        <div className="aline-lists">
                                                            <li><i class="fa fa-thumbs-up" aria-hidden="true"></i> 96 % </li>
                                                            <li><Link to="/">41 Patient Stories</Link></li>
                                                        </div>
                                                    </ul>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </div>
                                <div className="col-md-4">
                                <p><i class="fa fa-calendar-plus-o" aria-hidden="true"></i> Available Tomorrow</p>

                                </div>

                            </div>


                        </div>
                        <div className="col-md-4">
                          <h4>Side section</h4>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}
