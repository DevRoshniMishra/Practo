import React, { Component } from 'react'

export default class Pharmacy extends Component {
    render() {
        return (
            <div>
                <h4>Pharmacy Section</h4>
            </div>
        )
    }
}
