import React, { Component } from 'react'

export default class Consultant extends Component {
    render() {
        return (
            <div>
                <h4>ConsultantSection</h4>
            </div>
        )
    }
}
